from django.shortcuts import render, redirect, render_to_response

from signup.models import Staff
from .models import Car
from .models import Client


def sindex(request):
    return render (request, 'contents/sindex.html', locals())


def index(request):
    car = Car.objects.all().order_by('car_id')
    return render(request, 'contents/index.html', locals())

def index2(request):
    client = Client.objects.all().order_by('client_id')
    return render(request, 'contents/index2.html', locals())

def post1(request):
    if request.method == "POST":
        brand_name = request.POST['brand_name']
        type = request.POST['type']
        transmission = request.POST['transmission']
        price = request.POST['price']
        luggage_size = request.POST['luggage_size']
        seat_number = request.POST['seat_number']
        release_year = request.POST['release_year']


        car = Car.objects.create(brand_name=brand_name, type=type, transmission=transmission,
                                 price=price, luggage_size=luggage_size, seat_number=seat_number,
                                 release_year=release_year)
        car.save()
        return redirect('/index/')
    else:
        message = 'Enter information'
    return render(request, "contents/post1.html", locals())


def clientpost1(request):
    if request.method == "POST":
        client_name = request.POST.get('client_name', False)
        client_phone = request.POST.get('client_phone', False)
        client_address = request.POST.get('client_address', False)
        client_brithday = request.POST.get('client_brithday', False)
        client_occupation = request.POST.get('client_occupation', False)
        client_gender = request.POST.get('client_genter', False)


        client = Client.objects.create(client_name=client_name,  client_phone= client_phone, client_address =client_address,
                                       client_brithday=client_brithday, client_occupation=client_occupation, client_gender=client_gender)
        client.save()
        return redirect('/index2/')
    else:
        message = 'Enter information'
    return render(request, "contents/clientpost1.html", locals())

def delete(request,car_id=None):
    if car_id!=None:
        if request.method == "POST":
            car = request.POST('cId')
        try:
            car = Car.objects.get(car_id=car_id)
            car.delete()
            return redirect('/index/')
        except:
            message = "Error!"
    return render(request,"contents/delete.html",locals())

def cdelete(request,client_id=None):
    if client_id!=None:
        if request.method == "get":
            client = request.POST('cId')
        try:
            client = Client.objects.get(client_id=client_id)
            client.delete()
            return redirect('/index2/')
        except:
            message = "Error!"
    return render(request,"contents/cdelete.html",locals())

def edit(request,car_id=None,mode=None):
    if mode == "edit":
        car = Car.objects.get(car_id=car_id)
        car.brand_name = request.GET['brand_name']
        car.type = request.GET['type']
        car.transmission = request.GET['transmission']
        car.price = request.GET['price']
        car.luggage_size = request.GET['luggage_size']
        car.seat_number = request.GET['seat_number']
        car.release_year = request.GET['release_year']
        car.save()
        message = "Fixed"
        return redirect('/index/')
    else:
        try:
            car = Car.objects.get(car_id=car_id)
            strdate = str(car.car_id)
            strdate2 = strdate.replace("Y","-")
            strdate2 = strdate.replace("M","-")
            strdate2 = strdate.replace("D","-")
            car.car_id = strdate2
        except:
            message = "This id does not exist!"
    return render(request,"contents/edit.html",locals())



def clientedit(request,client_id=None,mode=None):
    if mode == "clientedit":
        client = Client.objects.get(client_id=client_id)
        client.client_name = request.GET['client_name']
        client.client_phone = request.GET['client_phone']
        client.client_address = request.GET['client_address']
        client.client_brithday = request.GET['client_brithday']
        client.client_occupation = request.GET['client_occupation']

        client.save()
        message = "Fixed"
        return redirect('/index2/')
    else:
        try:
            client = Client.objects.get(client_id=client_id)
            strdate = str(client.client_id)
            strdate2 = strdate.replace("Y","-")
            strdate2 = strdate.replace("M","-")
            strdate2 = strdate.replace("D","-")
            client.client_id = strdate2
        except:
            message = "This id does not exist!"
    return render(request,"contents/clientedit.html",locals())