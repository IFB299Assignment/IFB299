from django.apps import AppConfig


class RentalCarConfig(AppConfig):
    name = 'CarApp'
