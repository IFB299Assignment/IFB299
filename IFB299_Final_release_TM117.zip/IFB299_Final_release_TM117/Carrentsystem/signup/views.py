from django.shortcuts import render, redirect
from signup.models import Staff
from .forms import CustomerSignInForm, StaffSignInForm, CustomerSignUpForm
from . import models


def customer_sign_in(request):
    if request.session.get('signed_in', None):
        return redirect("/home/")
    if request.method == "POST":
        sign_in = CustomerSignInForm(request.POST)
        if sign_in.is_valid():
            customer_username = sign_in.cleaned_data['username']
            customer_password = sign_in.cleaned_data['password']
            try:
                customer = models.Customer.objects.get(username=customer_username)
                if customer.password == customer_password:
                    request.session['signed_in'] = True
                    request.session['username'] = customer.username
                    return redirect('/customerMainPage/')
                else:
                    notification = "Invalid username or password. Please try again"
            except:
                notification = "Invalid username or password. Please try again"
            return render(request, 'contents/customer_sign_in.html', locals())

    sign_in = CustomerSignInForm()
    return render(request, 'contents/customer_sign_in.html', locals())

def staff_sign_in(request):
    if request.session.get('staff_signed_in', None):
        return redirect("/home/")
    if request.method == "POST":
        sign_in_staff = StaffSignInForm(request.POST)
        if sign_in_staff.is_valid():
            staff_number = sign_in_staff.cleaned_data['staff_number']
            staff_password = sign_in_staff.cleaned_data['password']
            try:
                staff = models.Staff.objects.get(staff_number=staff_number)
                if staff.password == staff_password:
                    request.session['staff_signed_in'] = True
                    request.session['staff_number'] = staff.staff_number
                    request.session['first_name'] = staff.first_name
                    request.session['last_name'] = staff.last_name
                    return redirect('/staff_main_page/')
                else:
                    notification = "Invalid staff number or password. Please try again"
            except:
                notification = "Invalid username or password. Please try again"
            return render(request, 'contents/staff_sign_in.html', locals())

    sign_in_staff = StaffSignInForm()
    return render(request, 'contents/staff_sign_in.html', locals())

def signup(request):
    if request.session.get('signed_in', None):

        return redirect("/home/")

    if request.method == "POST":

        sign_up = CustomerSignUpForm(request.POST)

        if sign_up.is_valid():
            customer_first_name = sign_up.cleaned_data['first_name']
            customer_last_name = sign_up.cleaned_data['last_name']
            customer_username = sign_up.cleaned_data['username']
            customer_password = sign_up.cleaned_data['password']
            customer_repeat_password = sign_up.cleaned_data['repeat_password']
            email_address = sign_up.cleaned_data['email_address']
            gender = sign_up.cleaned_data['gender']

            if customer_repeat_password != customer_password:

                notification = "The password and the confirm password do not match"
                return render(request, 'contents/customer_sign_up.html', locals())

            email_used = models.Customer.objects.filter(email_address=email_address)
            if email_used:

                notification = "The email address has been used"
                return render(request, 'contents/customer_sign_up.html', locals())

            username_used = models.Customer.objects.filter(username=customer_username)
            if username_used:

                notification = "The username has been used"
                return render(request, 'contents/customer_sign_up.html', locals())

            new_customer_account = models.Customer.objects.create()
            new_customer_account.first_name = customer_first_name
            new_customer_account.last_name = customer_last_name
            new_customer_account.username = customer_username
            new_customer_account.email_address = email_address
            new_customer_account.password = customer_password
            new_customer_account.gender = gender
            new_customer_account.save()
            return redirect('/customer_sign_in/')

    sign_up = CustomerSignUpForm()
    return render(request, 'contents/customer_sign_up.html', locals())

def home(request):
    pass
    return render(request, 'contents/home.html')


def staff_main_page(request):
    pass
    return render(request, 'contents/staff_main_page.html')

def signout(request):
    if not request.session.get('signed_in', None):
        return redirect('/home/')
    request.session.flush()
    return redirect('/home/')

def staff_signout(request):
    if not request.session.get('staff_signed_in', None):
        return redirect('/home/')
    request.session.flush()
    return redirect('/home/')

def index3(request):
    staff = Staff.objects.all().order_by('id')
    return render(request, 'contents/index3.html', locals())

def post3(request):
    if request.method == "POST":
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        staff_number = request.POST['staff_number']
        password = request.POST['password']
        email_address = request.POST['email_address']
        gender = request.POST['gender']

        staff = Staff.objects.create( first_name= first_name, last_name =last_name ,staff_number=staff_number,
                                      password=password , email_address=email_address,gender=gender)
        staff.save()
        return redirect('/index3/')
    else:
        message = 'Enter information'
    return render(request, "contents/post3.html", locals())


def sdelete(request, id=None):
    if id != None:
        if request.method == "POST":
            staff = request.POST('cId')
        try:
            staff = Staff.objects.get (id=id)
            staff.delete ()
            return redirect ('/index3/')
        except:
            message = "Error!"
    return render (request, "contents/sdelete.html", locals())


def sedit(request,id=None,mode=None):
    if mode == "sedit":
        staff = Staff.objects.get(id=id)
        staff.first_name = request.GET['first_name']
        staff.last_name = request.GET['last_name']
        staff.staff_number = request.GET['staff_number']
        staff.password = request.GET['password']
        staff.email_address = request.GET['email_address']
        staff.gender = request.GET['gender']
        staff.created_date = request.GET['created_date']
        staff.save()
        message = "Fixed"
        return redirect('/index3/')
    else:
        try:
            staff = Staff.objects.get(id=id)
            strdate = str(staff.id)
            strdate2 = strdate.replace("Y","-")
            strdate2 = strdate.replace("M","-")
            strdate2 = strdate.replace("D","-")
            staff.id = strdate2
        except:
            message = "This id does not exist!"
    return render(request,"contents/sedit.html",locals())
