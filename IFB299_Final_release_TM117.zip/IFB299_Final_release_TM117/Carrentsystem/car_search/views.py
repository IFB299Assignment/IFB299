from django.shortcuts import render_to_response
from .models import Car, Record, Discount, Rental, PickUpStore, DropOffStore, Store, Client

def index(request):
     return render_to_response('contents/car_search.html')

def query(request):
    car_query = request.GET['car']
    cars = Car.objects.filter(car_id__icontains = car_query)
    return render_to_response('contents/car_search.html', {'car_query':car_query, 'cars': cars})

def record_query(request):
    record_query = request.GET['record']
    records = Record.objects.filter(record_id__icontains = record_query)
    return render_to_response('contents/car_search.html', {'record_query':record_query, 'records': records})

def discount_query(request):
    discount_query = request.GET['discount']
    discounts = Discount.objects.filter(discount_id__icontains = discount_query)
    return render_to_response('contents/car_search.html', {'discount_query':discount_query, 'discounts': discounts})

def rental_query(request):
    rental_query = request.GET['rental']
    rentals = Rental.objects.filter(rental_id__icontains = rental_query)
    return render_to_response('contents/car_search.html', {'rental_query':rental_query, 'rentals': rentals})

def pick_up_store_query(request):
    pick_up_store_query = request.GET['pick_up_store']
    pick_up_stores = PickUpStore.objects.filter(pick_up_store_id__icontains = pick_up_store_query)
    return render_to_response('contents/car_search.html', {'pick_up_store_query':pick_up_store_query, 'pick_up_stores': pick_up_stores})

def drop_off_store_query(request):
    drop_off_store_query = request.GET['drop_off_store']
    drop_off_stores = DropOffStore.objects.filter(drop_off_store_id__icontains = drop_off_store_query)
    return render_to_response('contents/car_search.html', {'drop_off_store_query':drop_off_store_query, 'drop_off_stores': drop_off_stores})

def store_query(request):
    store_query = request.GET['store']
    stores = Store.objects.filter(store_id__icontains = store_query)
    return render_to_response('contents/car_search.html', {'store_query':store_query, 'stores': stores})

def client_query(request):
    client_query = request.GET['client']
    clients = Client.objects.filter(client_id__icontains = client_query)
    return render_to_response('contents/car_search.html', {'client_query':client_query, 'clients': clients})
