from django.apps import AppConfig


class CarSearchConfig(AppConfig):
    name = 'car_search'
